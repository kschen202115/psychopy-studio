from .. import BaseStandaloneRoutine
from pathlib import Path


class UnknownRoutine(BaseStandaloneRoutine):
    categories = ['Other']
    targets = []
    iconFile = Path(__file__).parent / "unknown.png"
    iconSVG = Path(__file__).parent / 'UnknownRoutine.svg'
    tooltip = "Unknown routine"
    # hide from the Components panel
    hidden = True

    def __init__(self, exp, name=''):
        BaseStandaloneRoutine.__init__(self, exp, name=name)

    def writeMainCode(self, buff):
        code = (
            "\n"
            "# Unknown standalone routine ignored: %(name)s\n"
            "\n"
        )
        buff.writeIndentedLines(code % self.params)

    def writeRoutineBeginCodeJS(self, buff):
        code = (
            "\n"
            "// Unknown standalone routine ignored: %(name)s\n"
            "\n"
        )
        buff.writeIndentedLines(code % self.params)
